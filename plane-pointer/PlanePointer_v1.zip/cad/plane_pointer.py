"""
WolfTronix PLANE POINTER — parametric CAD (CadQuery 2.x)
=========================================================
2-axis pan/tilt arrow that points at the nearest aircraft.

  AZ: NEMA17 in the base -> 16T pinion -> 48T turntable gear (3:1) on a 6808-2RS bearing
  EL: NEMA17 on the yoke arm -> 16T pinion -> 48T gear on a 5 mm axle (3:1), 625ZZ bearings

Run:  python plane_pointer.py         -> writes ../print/*.stl, ../step/*.step, ../viewer/*.stl
All dimensions in mm.  Z = up, azimuth axis = Z axis, elevation axis parallel to Y.
Change the parameters below and re-run.
"""
import math, os
import cadquery as cq

# ---------------- parameters ----------------
MOD = 1.5            # gear module
Z_PIN, Z_RING = 16, 48   # 3:1
PA = 20              # pressure angle
BACKLASH = 0.15
CD = MOD * (Z_PIN + Z_RING) / 2      # centre distance = 48

BASE_D, BASE_H, WALL, TOP_T = 160, 85, 2.4, 4.0
ZTOP = BASE_H                       # top surface of base
BRG_ID, BRG_OD, BRG_W = 40, 52, 7   # 6808-2RS
RING_T = 10                         # turntable gear thickness
Z_GEAR0 = ZTOP + 1                  # turntable gear underside
YOKE_T = 6                          # yoke base thickness
Z_YOKE0 = Z_GEAR0 + RING_T          # = 96
AXLE_H = 86                         # axle height above yoke base bottom
ARM_IN, ARM_T, ARM_W = 26, 8, 50    # arm inner face |y|, thickness, width (x)
EL_GEAR_Y0, EL_GEAR_T = 15, 8       # el gear plane y 15..23
NEMA, NEMA_HOLE = 42.3, 31.0
SHAFT_D = 5.0
CLR = 0.2                           # general fit clearance

Z_AXLE = Z_YOKE0 + AXLE_H           # global axle height (182)

# ---------------- helpers ----------------
def involute_gear(z, th, m=MOD, pa=PA, bl=BACKLASH):
    rp = m * z / 2
    rb = rp * math.cos(math.radians(pa))
    ra = rp + m
    rf = rp - 1.25 * m
    inv = lambda a: math.tan(a) - a
    ap = math.radians(pa)
    half = math.pi / (2 * z) - bl / (2 * rp)
    r0 = max(rb, rf)
    def psi(r):
        r = max(r, rb)
        return half + inv(ap) - inv(math.acos(rb / r))
    rs = [r0 + (ra - r0) * i / 12 for i in range(13)]
    pts = []
    for i in range(z):
        c = i * 2 * math.pi / z
        prof = [(rf, c - psi(r0))] + [(r, c - psi(r)) for r in rs] + \
               [(r, c + psi(r)) for r in reversed(rs)] + [(rf, c + psi(r0))]
        pts += [(r * math.cos(a), r * math.sin(a)) for r, a in prof]
    clean = []
    for q in pts:
        if not clean or math.dist(q, clean[-1]) > 1e-3:
            clean.append(q)
    if math.dist(clean[0], clean[-1]) < 1e-3:
        clean.pop()
    return cq.Workplane("XY").polyline(clean).close().extrude(th)

def d_bore(depth, z0=-50):
    """5 mm D-shaft hole (flat 0.5 mm) along Z."""
    c = cq.Workplane("XY").workplane(offset=z0).circle(SHAFT_D / 2 + 0.1).extrude(depth)
    flat = cq.Workplane("XY").workplane(offset=z0).center(0, 2.05 + 5).rect(20, 10).extrude(depth)
    return c.cut(flat)

def ycyl(r, y0, y1, x=0, z=0):
    """cylinder along +Y from y0 to y1 at (x,z)"""
    return cq.Workplane("XZ").workplane(offset=-y0).center(x, z).circle(r).extrude(-(y1 - y0))

# ---------------- parts ----------------
def base_shell():
    s = cq.Workplane("XY").circle(BASE_D / 2).extrude(BASE_H)
    s = s.cut(cq.Workplane("XY").circle(BASE_D / 2 - WALL).extrude(BASE_H - TOP_T))
    s = s.edges(">Z").fillet(3)
    # bearing shoulder + press boss
    s = s.union(cq.Workplane("XY").workplane(offset=ZTOP).circle(22).extrude(1))
    s = s.union(cq.Workplane("XY").workplane(offset=ZTOP + 1).circle(BRG_ID / 2 - 0.05).extrude(BRG_W))
    s = s.cut(cq.Workplane("XY").circle(14).extrude(200))               # cable / slip-ring bore
    for a in (0, 120, 240):                                              # cap insert holes
        s = s.cut(cq.Workplane("XY").workplane(offset=ZTOP + 1 + BRG_W - 5)
                  .center(17 * math.cos(math.radians(a + 30)), 17 * math.sin(math.radians(a + 30)))
                  .circle(2.0).extrude(6))
    # AZ motor (hangs under the top plate, shaft up)
    s = s.cut(cq.Workplane("XY").center(CD, 0).circle(11.4).extrude(200))
    for dx in (-1, 1):
        for dy in (-1, 1):
            p = (CD + dx * NEMA_HOLE / 2, dy * NEMA_HOLE / 2)
            s = s.cut(cq.Workplane("XY").center(*p).circle(1.7).extrude(200))
            s = s.cut(cq.Workplane("XY").workplane(offset=ZTOP - 1.8).center(*p).circle(1.7).workplane(offset=1.8).circle(3.4).loft())
    # speaker grille at (0,-55) + clamp ring underneath
    gx, gy = 0, -55
    for r in (0, 6, 12):
        n = 1 if r == 0 else int(2 * math.pi * r / 6)
        for k in range(n):
            a = 2 * math.pi * k / n
            s = s.cut(cq.Workplane("XY").center(gx + r * math.cos(a), gy + r * math.sin(a)).circle(1.6).extrude(200))
    s = s.union(cq.Workplane("XY").workplane(offset=BASE_H - TOP_T - 4).center(gx, gy).circle(22).circle(20.3).extrude(4))
    # A3144 hall sensor pocket (AZ home) at r=30, 180 deg
    s = s.cut(cq.Workplane("XY").workplane(offset=ZTOP - 1.8).center(-30, 0).rect(4.4, 3.4).extrude(2))
    s = s.cut(cq.Workplane("XY").center(-30, 0).rect(3.2, 1.4).extrude(200))
    # screw columns for bottom plate
    for a in (45, 135, 225, 315):
        x, y = 72 * math.cos(math.radians(a)), 72 * math.sin(math.radians(a))
        s = s.union(cq.Workplane("XY").center(x, y).circle(4.5).extrude(BASE_H - TOP_T))
        s = s.cut(cq.Workplane("XY").center(x, y).circle(1.25).extrude(14))
    s = s.intersect(cq.Workplane("XY").circle(BASE_D / 2).extrude(200))
    # DC jack (+Y wall) and USB-C slot (-Y wall) and vents (-X)
    s = s.cut(ycyl(4.1, 60, 90, 0, 18))
    s = s.cut(cq.Workplane("XY").workplane(offset=11).center(0, -76).rect(14, 10).extrude(9))
    for k in range(-3, 4):
        a = math.radians(180 + k * 9)
        s = s.cut(cq.Workplane("XY").workplane(offset=10).center(77 * math.cos(a), 77 * math.sin(a))
                  .rect(8, 3).extrude(30).rotate((77 * math.cos(a), 77 * math.sin(a), 0), (77 * math.cos(a), 77 * math.sin(a), 1), math.degrees(a)))
    return s

def bottom_plate():
    p = cq.Workplane("XY").workplane(offset=-3).circle(BASE_D / 2).extrude(3)
    for a in (45, 135, 225, 315):
        x, y = 72 * math.cos(math.radians(a)), 72 * math.sin(math.radians(a))
        p = p.cut(cq.Workplane("XY").workplane(offset=-3).center(x, y).circle(1.7).extrude(3))
        p = p.cut(cq.Workplane("XY").workplane(offset=-3).center(x, y).circle(3.4).workplane(offset=1.8).circle(1.7).loft())
    # 50x70 perfboard standoffs, centre (0,-35)
    for dx in (-22.5, 22.5):
        for dy in (-32.5, 32.5):
            p = p.union(cq.Workplane("XY").center(dx, -35 + dy).circle(3).extrude(6))
            p = p.cut(cq.Workplane("XY").center(dx, -35 + dy).circle(1.2).extrude(6))
    # DY-SV5W cradle (40x40) centre (-50,10)
    p = p.union(cq.Workplane("XY").center(-50, 10).rect(44, 44).rect(40.6, 40.6).extrude(5))
    # rubber feet recesses
    for a in (0, 90, 180, 270):
        x, y = 60 * math.cos(math.radians(a + 45)), 60 * math.sin(math.radians(a + 45))
        p = p.cut(cq.Workplane("XY").workplane(offset=-3).center(x, y).circle(6.2).extrude(0.8))
    return p

def bearing_cap():
    c = cq.Workplane("XY").workplane(offset=ZTOP + 1 + BRG_W).circle(22).circle(11.6).extrude(2.5)
    for a in (0, 120, 240):
        x, y = 17 * math.cos(math.radians(a + 30)), 17 * math.sin(math.radians(a + 30))
        c = c.cut(cq.Workplane("XY").workplane(offset=ZTOP).center(x, y).circle(1.7).extrude(20))
    return c

def az_ring_gear():
    g = involute_gear(Z_RING, RING_T).translate((0, 0, Z_GEAR0))
    g = g.cut(cq.Workplane("XY").workplane(offset=Z_GEAR0).circle(BRG_OD / 2 + 0.1).extrude(BRG_W))
    g = g.cut(cq.Workplane("XY").circle(23.5).extrude(300))
    for a in (45, 135, 225, 315):   # yoke heat-set inserts
        g = g.cut(cq.Workplane("XY").workplane(offset=Z_GEAR0 + RING_T - 5.5).center(30 * math.cos(math.radians(a)), 30 * math.sin(math.radians(a))).circle(2.0).extrude(6))
    g = g.cut(cq.Workplane("XY").workplane(offset=Z_GEAR0).center(30, 0).circle(3.1).extrude(3.2))  # home magnet 6x3
    return g

def pinion(th, hub_len, hub_side=+1):
    g = involute_gear(Z_PIN, th)
    hub = cq.Workplane("XY").workplane(offset=th if hub_side > 0 else -hub_len).circle(8).extrude(hub_len)
    g = g.union(hub).cut(d_bore(200, -100))
    zc = th + hub_len / 2 if hub_side > 0 else -hub_len / 2
    g = g.cut(cq.Workplane("YZ").workplane(offset=0).center(0, zc).circle(1.25).extrude(10))   # M3 grub (tap)
    return g

def yoke():
    y = cq.Workplane("XY").rect(ARM_W, 2 * (ARM_IN + ARM_T)).extrude(YOKE_T)
    y = y.edges("|Z").fillet(6)
    y = y.cut(cq.Workplane("XY").circle(12).extrude(YOKE_T))
    for a in (45, 135, 225, 315):
        x0, y0 = 30 * math.cos(math.radians(a)), 30 * math.sin(math.radians(a))
        y = y.cut(cq.Workplane("XY").center(x0, y0).circle(1.7).extrude(YOKE_T))
        y = y.cut(cq.Workplane("XY").workplane(offset=YOKE_T - 3).center(x0, y0).circle(3.1).extrude(3))
    top = AXLE_H + 20
    for s in (+1, -1):
        arm = cq.Workplane("XY").center(0, s * (ARM_IN + ARM_T / 2)).rect(ARM_W, ARM_T).extrude(top)
        arm = arm.edges("|Y and >Z").fillet(12)
        y = y.union(arm)
        # gussets
        for gx in (-ARM_W / 2 + 3, ARM_W / 2 - 3):
            pts = [(s * ARM_IN, YOKE_T), (s * (ARM_IN - 10), YOKE_T), (s * ARM_IN, YOKE_T + 18)]
            y = y.union(cq.Workplane("YZ").workplane(offset=gx - 1.5).polyline(pts).close().extrude(3))
        # bearing pocket + axle hole
        y = y.cut(ycyl(3.2, -60, 60, 0, AXLE_H))
        y0 = s * ARM_IN
        y = y.cut(ycyl(8.05, min(y0, y0 + s * 5.0), max(y0, y0 + s * 5.0), 0, AXLE_H))
    # EL motor on +Y arm outer face
    zp = AXLE_H - CD
    y = y.cut(ycyl(11.4, ARM_IN - 1, ARM_IN + ARM_T + 1, 0, zp))
    for dx in (-1, 1):
        for dz in (-1, 1):
            y = y.cut(ycyl(1.7, ARM_IN - 1, ARM_IN + ARM_T + 1, dx * NEMA_HOLE / 2, zp + dz * NEMA_HOLE / 2))
    # elevation hard stop (StallGuard homing) on +Y arm inner face: arc r 39..47, XZ angle -66..-54
    pts = []
    for a in range(-69, -56, 2):
        pts.append((39 * math.cos(math.radians(a)), AXLE_H + 39 * math.sin(math.radians(a))))
    for a in range(-57, -70, -2):
        pts.append((47 * math.cos(math.radians(a)), AXLE_H + 47 * math.sin(math.radians(a))))
    stop = cq.Workplane("XZ").workplane(offset=-17).polyline(pts).close().extrude(-(ARM_IN - 17) - 0.5)
    y = y.union(stop)
    return y.translate((0, 0, Z_YOKE0))

def el_gear():
    g = involute_gear(Z_RING, EL_GEAR_T)
    g = g.union(cq.Workplane("XY").workplane(offset=-9).circle(7).extrude(9))
    g = g.union(cq.Workplane("XY").circle(16).extrude(EL_GEAR_T))
    # lightening holes
    for k in range(5):
        a = 2 * math.pi * k / 5 + 0.3
        g = g.cut(cq.Workplane("XY").center(25 * math.cos(a), 25 * math.sin(a)).circle(5.5).extrude(EL_GEAR_T))
    # stop tab at local angle +47 deg (-> XZ angle -47 deg at el=0)
    a = math.radians(47)
    tab = cq.Workplane("XY").workplane(offset=1).center(38.5 * math.cos(a), 38.5 * math.sin(a)).rect(11, 7).extrude(6)
    tab = tab.rotate((38.5 * math.cos(a), 38.5 * math.sin(a), 0), (38.5 * math.cos(a), 38.5 * math.sin(a), 1), 47)
    g = g.union(tab)
    g = g.cut(cq.Workplane("XY").workplane(offset=-20).circle(SHAFT_D / 2 + 0.1).extrude(40))
    g = g.cut(cq.Workplane("YZ").center(0, -4.5).circle(1.25).extrude(10))   # grub
    # rotate so axis is along +Y, gear plane at y 15..23
    return g.rotate((0, 0, 0), (1, 0, 0), -90).translate((0, EL_GEAR_Y0, Z_AXLE))

def el_pinion():
    p = pinion(EL_GEAR_T, 5, hub_side=-1)
    p = p.rotate((0, 0, 0), (0, 0, 1), 180 / Z_PIN)          # half-tooth phase so teeth mesh
    return p.rotate((0, 0, 0), (1, 0, 0), -90).translate((0, EL_GEAR_Y0, Z_AXLE - CD))

def az_pinion():
    return pinion(RING_T, 8, hub_side=+1).rotate((0, 0, 0), (0, 0, 1), 180 / Z_PIN).translate((CD, 0, Z_GEAR0))

ARROW_OUTLINE = [(-56, -8), (-40, -5), (72, -5), (72, 5), (-40, 5), (-56, 8), (-51, 0)]  # tail fins kept inside |y|<8 to clear the EL pinion at 90 deg
def arrow_body():
    a = cq.Workplane("XY").workplane(offset=-5).polyline(ARROW_OUTLINE).close().extrude(10)
    hub = ycyl(8, -12, 4)
    a = a.union(hub)
    a = a.intersect(cq.Workplane("XY").workplane(offset=-5).rect(400, 400).extrude(10))   # flat both sides
    a = a.cut(ycyl(SHAFT_D / 2 + 0.1, -30, 30))
    a = a.cut(cq.Workplane("XY").center(0, -6).circle(1.25).extrude(10))                    # M3 grub from top
    a = a.cut(cq.Workplane("XY").workplane(offset=-2).center(-34, 0).circle(4.5).extrude(10))  # counterweight pocket (M8 nuts / lead shot)
    return a.translate((0, 0, Z_AXLE))

def arrow_tip():
    t = cq.Workplane("XY").workplane(offset=-4).polyline([(72, -18), (114, 0), (72, 18), (78, 0)]).close().extrude(8)
    return t.translate((0, 0, Z_AXLE))

# ---------------- non-printed reference parts (for the viewer) ----------------
def nema(face_center, axis, length=40):
    b = cq.Workplane("XY").rect(NEMA, NEMA).extrude(-length).edges("|Z").chamfer(4)
    b = b.union(cq.Workplane("XY").circle(11).extrude(2)).union(cq.Workplane("XY").circle(2.5).extrude(24))
    if axis == "-y":
        b = b.rotate((0, 0, 0), (1, 0, 0), 90)
    return b.translate(face_center)

def ring(od, idd, z0, h, center=(0, 0)):
    return cq.Workplane("XY").workplane(offset=z0).center(*center).circle(od / 2).circle(idd / 2).extrude(h)

def ref_parts():
    r = {}
    r["ref_az_motor"] = nema((CD, 0, ZTOP - TOP_T), "z")
    r["ref_el_motor"] = nema((0, ARM_IN + ARM_T, Z_AXLE - CD), "-y")
    r["ref_bearing_6808"] = ring(BRG_OD, BRG_ID, Z_GEAR0, BRG_W)
    r["ref_axle"] = ycyl(2.5, -40, 30, 0, Z_AXLE)
    r["ref_625zz"] = ycyl(8, ARM_IN, ARM_IN + 5, 0, Z_AXLE).union(ycyl(8, -ARM_IN - 5, -ARM_IN, 0, Z_AXLE))
    r["ref_perfboard"] = cq.Workplane("XY").workplane(offset=6).center(0, -35).rect(50, 70).extrude(1.6)
    r["ref_esp32s3"] = cq.Workplane("XY").workplane(offset=16).center(0, -40).rect(27, 63).extrude(10)
    r["ref_tmc2209"] = cq.Workplane("XY").workplane(offset=14).center(-15, -5).rect(15, 20).extrude(14).union(
        cq.Workplane("XY").workplane(offset=14).center(15, -5).rect(15, 20).extrude(14))
    r["ref_dysv5w"] = cq.Workplane("XY").workplane(offset=1).center(-50, 10).rect(40, 40).extrude(9)
    r["ref_speaker"] = cq.Workplane("XY").workplane(offset=BASE_H - TOP_T - 6).center(0, -55).circle(20).extrude(6)
    r["ref_slipring"] = cq.Workplane("XY").workplane(offset=ZTOP - 30).circle(11).extrude(40)
    return r

PRINTED = {
    "base_shell": base_shell, "bottom_plate": bottom_plate, "bearing_cap": bearing_cap,
    "az_ring_gear_48T": az_ring_gear, "az_pinion_16T": az_pinion, "yoke": yoke,
    "el_gear_48T": el_gear, "el_pinion_16T": el_pinion, "arrow_body": arrow_body, "arrow_tip": arrow_tip,
}
# how each part is laid on the bed: (rotate about X deg, rotate about Y deg)
PRINT_ORIENT = {"base_shell": (180, 0), "az_ring_gear_48T": (180, 0), "el_gear_48T": (90, 0),
                "el_pinion_16T": (-90, 0), "bearing_cap": (0, 0)}

def lay_flat(shape, rx):
    s = shape.rotate((0, 0, 0), (1, 0, 0), rx) if rx else shape
    bb = s.val().BoundingBox()
    return s.translate((-(bb.xmin + bb.xmax) / 2, -(bb.ymin + bb.ymax) / 2, -bb.zmin))

if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__))
    out = {k: os.path.join(here, "..", k) for k in ("print", "step", "viewer")}
    for d in out.values():
        os.makedirs(d, exist_ok=True)
    asm = cq.Assembly(name="plane_pointer")
    for name, fn in PRINTED.items():
        s = fn()
        cq.exporters.export(s, os.path.join(out["viewer"], name + ".stl"), tolerance=0.08, angularTolerance=0.15)
        flat = lay_flat(s, PRINT_ORIENT.get(name, (0, 0))[0])
        cq.exporters.export(flat, os.path.join(out["print"], name + ".stl"), tolerance=0.03, angularTolerance=0.1)
        cq.exporters.export(flat, os.path.join(out["step"], name + ".step"))
        asm.add(s, name=name)
        bb = s.val().BoundingBox()
        print(f"{name:20s} {bb.xlen:6.1f} x {bb.ylen:6.1f} x {bb.zlen:6.1f}  vol {s.val().Volume()/1000:6.1f} cm3")
    for name, s in ref_parts().items():
        cq.exporters.export(s, os.path.join(out["viewer"], name + ".stl"), tolerance=0.1, angularTolerance=0.2)
        asm.add(s, name=name)
    asm.save(os.path.join(out["step"], "plane_pointer_assembly.step"))
    print("done")
