import cadquery as cq, math
import plane_pointer as P
parts={k:f() for k,f in P.PRINTED.items()}
ref=P.ref_parts()
def vol(a,b):
    try: return a.intersect(b).val().Volume()
    except Exception as e: return 0.0
def el_rot(s,el): return s.rotate((0,0,P.Z_AXLE),(0,1,P.Z_AXLE),-el)
print('az pinion vs ring', round(vol(parts['az_pinion_16T'],parts['az_ring_gear_48T']),2))
print('el pinion vs el gear', round(vol(parts['el_pinion_16T'],parts['el_gear_48T']),2))
print('ring vs base', round(vol(parts['az_ring_gear_48T'],parts['base_shell']),2))
print('yoke vs ring', round(vol(parts['yoke'],parts['az_ring_gear_48T']),2), 'yoke vs cap',round(vol(parts['yoke'],parts['bearing_cap']),2),'yoke vs azpinion',round(vol(parts['yoke'],parts['az_pinion_16T']),2))
print('elmotor vs azpinion', round(vol(ref['ref_el_motor'],parts['az_pinion_16T']),2),'elmotor vs yoke',round(vol(ref['ref_el_motor'],parts['yoke']),2))
print('azmotor vs base', round(vol(ref['ref_az_motor'],parts['base_shell']),2))
for el in (-6,-5,-4,0,45,80,90,95):
    g=el_rot(parts['el_gear_48T'],el); a=el_rot(parts['arrow_body'],el); t=el_rot(parts['arrow_tip'],el)
    print(f'el {el:4d}: gear-yoke {vol(g,parts["yoke"]):7.2f}  arrow-yoke {vol(a,parts["yoke"]):6.2f} tip-yoke {vol(t,parts["yoke"]):6.2f} gear-pinion(body) {vol(g,parts["el_pinion_16T"]):6.2f} arrow-gear {vol(a,g):6.2f} arrow-elmotor {vol(a,ref["ref_el_motor"]):5.2f} arrow-pinion {vol(a,parts["el_pinion_16T"]):5.2f}')
