# WolfTronix Plane Pointer — design package v1

2-axis pan/tilt arrow that points at the nearest aircraft over Escondido and announces it via a DY-SV5W.

## Folders
| Folder | Contents |
|---|---|
| `print/` | STL files already oriented for the Bambu X2D bed |
| `step/` | STEP per part (same orientation) + `plane_pointer_assembly.step` (everything in place, incl. reference motors/bearings/electronics) |
| `cad/plane_pointer.py` | Parametric CadQuery source. Change module, ratio, base size, bearing… and run `python plane_pointer.py` (`pip install cadquery`) |
| `cad/check.py` | Interference check (gear mesh, elevation sweep −5…95°) |
| `firmware/` | MicroPython for ESP32-S3: copy `main.py config.py geo.py announcer.py stepper.py tmc2209.py dysv5w.py` with `mpremote cp` |
| `firmware/make_clips.py` | Run on your PC: `pip install edge-tts` → `python make_clips.py` → copy `ZH/` to the SD card root |

## Quick start
1. Print: `base_shell`, `bottom_plate`, `bearing_cap`, `az_ring_gear_48T`, `az_pinion_16T`, `yoke`, `el_gear_48T`, `el_pinion_16T`, `arrow_body` + `arrow_tip` (one object, two filaments).
2. Edit `firmware/config.py`: WiFi password, your exact HOME_LAT/LON/ALT, ADSB_SOURCE.
3. `mpremote cp firmware/*.py :` (skip make_clips.py / test_desktop.py), reset.
4. After homing, open `http://<ip>/point?az=188&el=0` — the arrow should face Montgomery (KMYF). Rotate the base, or set `AZ_HOME_DEG`, until it does.

## Key specs
- 3:1 module-1.5 spur gears both axes, 4,800 µsteps per output rev at 1/8 µstep (0.075°)
- AZ on a 6808-2RS (40×52×7) bearing; EL axle Ø5 on 2× 625ZZ
- Homing: A3144 hall + 6×3 magnet (AZ), StallGuard against a printed stop at −5° (EL)
- ADS-B: adsb.lol / airplanes.live `/v2/point/lat/lon/nm`, or local readsb `aircraft.json`

Untested on real hardware: tune `SGTHRS`, VREF current and `AZ_HOME_DEG` on the first power-up.
