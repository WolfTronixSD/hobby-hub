# Desktop tests for the pure-python parts (run with CPython): geo math, announcer, planner, TMC CRC.
import math, geo, announcer
from stepper import Planner
from tmc2209 import crc8

H = (33.1192, -117.0864, 200.0)
# 1) Aircraft due north 10 km at 10,000 ft -> az ~0, el ~ atan(2848/10000) ~ 15.9 deg (minus curvature)
lat = H[0] + 10000 / 111320
az, el, rng, g = geo.az_el_range(*H, lat, H[1], 10000 * geo.FT)
print("north 10km 10kft:", round(az, 2), round(el, 2), round(rng), round(g))
assert abs(az) < 0.5 or abs(az - 360) < 0.5
assert 15.0 < el < 16.2
# 2) KMYF from Escondido: bearing ~ 192 deg, ~35 km
b = geo.bearing(H[0], H[1], 32.8157, -117.1396); d = geo.haversine_km(H[0], H[1], 32.8157, -117.1396)
az2, el2, _, _ = geo.az_el_range(*H, 32.8157, -117.1396, 129)
print("KMYF bearing", round(b, 1), "dist", round(d, 1), "km  enu-az", round(az2, 1), "el", round(el2, 2))
assert abs(b - az2) < 0.3
# 3) Announcer
ac = {"flight": "SWA1234", "alt_ft": 8040, "lat": 32.95, "lon": -117.05, "track": 225, "baro_rate": -900}
dest = geo.guess_destination(ac, H[0], H[1])
w = announcer.sentence(ac, dest, 12.0)
print(" ".join(w)); print(announcer.to_codes(w))
assert "Southwest" in w and "Lindbergh" in w and "thousand" in w
print(" ".join(announcer.sentence({"flight": "N731BP", "alt_ft": 3500}, None, None, "west")))
print(" ".join(announcer.sentence({"flight": "UAL2", "alt_ft": 35000}, None, None, "east")))
print("clips:", len(announcer.CLIPS), "files, codes", min(announcer.CLIPS.values()), "..", max(announcer.CLIPS.values()))
# 4) Planner: move 180 deg on a 3:1 axis at 1/8 microstep, check it lands exactly and respects vmax
p = Planner(200 * 8 / 360 * 3, 90, 180); p.move_to(180); t = 0; vmax = 0
while p.busy() and t < 20:
    p.chunk(); t += 0.04; vmax = max(vmax, abs(p.v) / p.spu)
print("180 deg move:", round(t, 2), "s  final", p.unit(), "peak", round(vmax, 1), "deg/s")
assert p.unit() == 180 and vmax <= 90.01
p.move_to(170)   # retarget backward
while p.busy(): p.chunk()
assert abs(p.unit() - 170) < 0.1
# 5) TMC2209 CRC: datasheet example read of IFCNT for address 0 -> 05 00 02 CRC
print("crc", hex(crc8(bytes([0x05, 0x00, 0x02]))))
print("ALL OK")
