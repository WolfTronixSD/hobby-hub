# Two-axis stepper motion using the ESP32 RMT peripheral: every 40 ms the planner decides how many
# steps each axis makes in the next chunk; RMT emits them as evenly spaced hardware-timed pulses.
# Trapezoidal velocity (accel-limited), retargetable at any time - same model as the web sim.
import math

CHUNK_S = 0.04

class Planner:
    """pure-python velocity planner (also runs on a PC for testing)"""
    def __init__(self, steps_per_unit, vmax_u, acc_u):
        self.spu = steps_per_unit
        self.vmax = vmax_u * steps_per_unit
        self.acc = acc_u * steps_per_unit
        self.pos = 0          # steps (int)
        self.v = 0.0          # steps/s
        self.target = 0
        self._frac = 0.0

    def set_unit(self, u):    self.pos = int(round(u * self.spu)); self.target = self.pos; self.v = 0.0
    def move_to(self, u):     self.target = int(round(u * self.spu))
    def unit(self):           return self.pos / self.spu
    def busy(self):           return self.pos != self.target or abs(self.v) > 1

    def chunk(self, dt=CHUNK_S):
        d = self.target - self.pos
        if d == 0 and abs(self.v) < self.acc * dt:
            self.v = 0.0; self._frac = 0.0
            return 0
        want = math.copysign(min(self.vmax, math.sqrt(2 * self.acc * abs(d))), d) if d else 0.0
        dv = max(-self.acc * dt, min(self.acc * dt, want - self.v))
        self.v += dv
        n = self.v * dt + self._frac
        steps = int(n)
        self._frac = n - steps
        if (steps > 0 and steps > d > 0) or (steps < 0 and steps < d < 0):
            steps = d; self._frac = 0.0
        self.pos += steps
        return steps

try:
    import esp32
    from machine import Pin

    class Axis(Planner):
        def __init__(self, ch, step_pin, dir_pin, steps_per_unit, vmax_u, acc_u, invert=False):
            super().__init__(steps_per_unit, vmax_u, acc_u)
            self.rmt = esp32.RMT(ch, pin=Pin(step_pin, Pin.OUT), clock_div=80, idle_level=False)  # 1 us ticks
            self.dir = Pin(dir_pin, Pin.OUT)
            self.inv = invert

        def emit(self, steps, dt=CHUNK_S):
            if steps == 0:
                return
            self.dir.value((steps > 0) ^ self.inv)
            n = abs(steps)
            period = int(dt * 1_000_000 / n)
            low = min(32000, max(3, period - 4))     # RMT item max 32767 ticks (slow moves bunch slightly)
            pulses = [4, low] * n                    # 4 us high, then low
            self.rmt.write_pulses(pulses, True)

        def done(self):
            return self.rmt.wait_done()
except ImportError:      # running on a PC
    Axis = None
