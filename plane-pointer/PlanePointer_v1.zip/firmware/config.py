# ---------------- Plane Pointer configuration ----------------
WIFI_SSID = "Belkin.52a9"
WIFI_PASS = "your-wifi-password"

# Observer = the pointer itself (WGS-84). Set to your house; altitude of the arrow above MSL.
HOME_LAT = 33.1192          # Escondido (edit to your exact spot)
HOME_LON = -117.0864
HOME_ALT_M = 200.0

# ADS-B source: "adsb.lol", "airplanes.live" or "local" (your RTL-SDR running readsb / tar1090)
ADSB_SOURCE = "adsb.lol"
LOCAL_URL = "http://192.168.2.50/tar1090/data/aircraft.json"
RADIUS_NM = 25
POLL_S = 5                  # public APIs ask for <= 1 req/s; 5 s is polite

# Target selection
MODE = "nearest"            # nearest | lowest | arrivals | watch
WATCH = ["N123AB"]          # callsigns / registrations / hex for "watch" mode
MIN_EL_DEG = 1.5            # ignore aircraft below this elevation (terrain / houses)
MAX_RANGE_KM = 45
SWITCH_HYST = 0.85          # new target must be 15 % closer before we switch
IDLE_POINT = "KMYF"         # where to point when the sky is empty (None = park)

# Mechanics
STEPS_PER_REV = 200
MICROSTEPS = 8              # TMC2209 interpolates to 256 -> silent
AZ_RATIO = 3.0              # 48T / 16T
EL_RATIO = 3.0
AZ_VMAX_DEG_S = 90          # output-shaft speeds
AZ_ACC_DEG_S2 = 180
EL_VMAX_DEG_S = 60
EL_ACC_DEG_S2 = 150
EL_MIN, EL_MAX = -5.0, 92.0   # -5 = printed hard stop
AZ_HOME_DEG = 180.0         # true bearing the arrow faces when the hall sensor triggers (calibrate!)
AZ_INVERT = False
EL_INVERT = False
SLIP_RING = True            # False -> cable-wrap mode, azimuth limited to +/-270 deg
AZ_WRAP_LIMIT = 270

# Pins (ESP32-S3-DevKitC-1 N16R8; avoids flash/PSRAM pins 26-37 and strapping pins)
PIN_AZ_STEP, PIN_AZ_DIR = 4, 5
PIN_EL_STEP, PIN_EL_DIR = 6, 7
PIN_EN = 15                 # shared, active low
PIN_EL_DIAG = 8             # TMC2209 DIAG of the EL driver (StallGuard)
PIN_AZ_HALL = 9             # A3144, open collector, pulled up
PIN_TMC_TX, PIN_TMC_RX = 17, 18   # UART1 -> both PDN_UART pins (TX via 1k)
PIN_DY_TX, PIN_DY_RX = 10, 11     # UART2 -> DY-SV5W RXD / TXD
PIN_DY_BUSY = 12
PIN_PIXEL = 48              # on-board RGB LED (v1.0 boards; 38 on v1.1)

# TMC2209
TMC_ADDR_AZ, TMC_ADDR_EL = 0, 1   # MS1/MS2 strapping: AZ = 00, EL = 10
IRUN, IHOLD = 18, 8               # 0..31 (scaled by the VREF pot)
SGTHRS = 70                       # StallGuard threshold for EL homing (tune 40..120)

# Audio
VOLUME = 22                 # 0..30
ANNOUNCE_DISTANCE = True
REANNOUNCE_S = 300          # don't repeat the same aircraft within 5 min
