"""
Run on your PC (not the ESP32) to create the DY-SV5W voice clips.

    pip install edge-tts
    python make_clips.py            -> ./ZH/*.mp3   (copy the ZH folder to the root of the micro-SD card)

Uses Microsoft Edge neural TTS (needs internet). Voice can be changed below, e.g. "en-US-GuyNeural",
"en-US-JennyNeural", or a German voice "de-DE-ConradNeural" for fun.
Also writes clips.csv so you can see which 2-char file holds which word.
"""
import asyncio, csv, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from announcer import CLIPS

VOICE = "en-US-GuyNeural"
RATE = "+12%"            # a little brisk, ATC style

SPOKEN = {"U P S": "U.P.S.", "x-ray": "x-ray", "niner": "niner", "chime": None}

async def main():
    import edge_tts
    os.makedirs("ZH", exist_ok=True)
    with open("clips.csv", "w", newline="") as f:
        w = csv.writer(f); w.writerow(["file", "word"])
        for word, code in CLIPS.items():
            w.writerow([f"/ZH/{code}.mp3", word])
            path = os.path.join("ZH", f"{code}.mp3")
            if os.path.exists(path):
                continue
            text = SPOKEN.get(word, word)
            if text is None:
                print(f"{code}: put your own short chime sound here as ZH/{code}.mp3")
                continue
            await edge_tts.Communicate(text, VOICE, rate=RATE).save(path)
            print(code, word)

asyncio.run(main())
