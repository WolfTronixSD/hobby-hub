# WolfTronix PLANE POINTER — ESP32-S3 / MicroPython 1.23+
# ADS-B -> nearest aircraft -> az/el -> two NEMA17 (TMC2209, RMT step pulses) -> DY-SV5W announcements
# Web status page on http://<ip>/  (mode, volume, re-home, manual point)
import time, math, gc, network, asyncio, json
from machine import Pin, UART
import config as C
import geo, announcer
from stepper import Axis, CHUNK_S
from tmc2209 import TMC2209
from dysv5w import DY

try:
    import requests
except ImportError:
    import urequests as requests

# ---------------- hardware ----------------
en = Pin(C.PIN_EN, Pin.OUT, value=1)
hall = Pin(C.PIN_AZ_HALL, Pin.IN, Pin.PULL_UP)
diag = Pin(C.PIN_EL_DIAG, Pin.IN)
spu = C.STEPS_PER_REV * C.MICROSTEPS / 360.0
az = Axis(0, C.PIN_AZ_STEP, C.PIN_AZ_DIR, spu * C.AZ_RATIO, C.AZ_VMAX_DEG_S, C.AZ_ACC_DEG_S2, C.AZ_INVERT)
el = Axis(1, C.PIN_EL_STEP, C.PIN_EL_DIR, spu * C.EL_RATIO, C.EL_VMAX_DEG_S, C.EL_ACC_DEG_S2, C.EL_INVERT)
tmc_uart = UART(1, 115200, tx=C.PIN_TMC_TX, rx=C.PIN_TMC_RX)
tmc_az, tmc_el = TMC2209(tmc_uart, C.TMC_ADDR_AZ), TMC2209(tmc_uart, C.TMC_ADDR_EL)
dy = DY(2, C.PIN_DY_TX, C.PIN_DY_RX, C.PIN_DY_BUSY)
try:
    import neopixel
    px = neopixel.NeoPixel(Pin(C.PIN_PIXEL), 1)
except Exception:
    px = None

def led(r, g, b):
    if px:
        px[0] = (r, g, b); px.write()

state = {"mode": C.MODE, "target": None, "az_cmd": 0.0, "el_cmd": 0.0, "n": 0, "err": "", "manual": None,
         "last_fetch": 0, "homed": False}
aircraft = []          # list of dicts with lat/lon/alt_ft/gs/track/flight/hex, t0 = ticks at fetch
announced = {}         # hex -> ticks_ms

# ---------------- motion ----------------
def az_command(true_az):
    """choose the az setpoint (continuous with slip ring, limited without)"""
    cur = az.target / az.spu
    best = cur + geo.ang_diff(true_az, cur % 360)
    if not C.SLIP_RING:
        lim = C.AZ_WRAP_LIMIT
        if best > lim: best -= 360
        if best < -lim: best += 360
    return best

def point(true_az, elev):
    state["az_cmd"], state["el_cmd"] = true_az, elev
    az.move_to(az_command(true_az))
    el.move_to(max(C.EL_MIN, min(C.EL_MAX, elev)))

async def motion_task():
    while True:
        sa, se = az.chunk(), el.chunk()
        az.emit(sa); el.emit(se)
        await asyncio.sleep(CHUNK_S)
        while not (az.done() and el.done()):
            await asyncio.sleep_ms(1)

async def home():
    led(40, 20, 0)
    en.value(0)
    tmc_az.setup(C.MICROSTEPS, C.IRUN, C.IHOLD)
    tmc_el.setup(C.MICROSTEPS, C.IRUN // 2, C.IHOLD, C.SGTHRS)      # low current while homing EL
    # EL: drive down into the printed hard stop; StallGuard DIAG (or timeout) marks it
    el.set_unit(C.EL_MAX + 10)
    el.move_to(C.EL_MIN - 30)
    t0 = time.ticks_ms()
    await asyncio.sleep_ms(300)
    while time.ticks_diff(time.ticks_ms(), t0) < 6000:
        if diag.value():
            break
        await asyncio.sleep_ms(5)
    el.target = el.pos; el.v = 0
    await asyncio.sleep_ms(200)
    el.set_unit(C.EL_MIN)
    tmc_el.current(C.IRUN, C.IHOLD)
    el.move_to(10)
    # AZ: slow search for the hall magnet (max 1.2 turns), then back off and re-approach
    az.set_unit(0)
    az.vmax = 30 * az.spu
    az.move_to(-440 if hall.value() == 0 else 440)
    if hall.value() == 0:                       # already on the magnet: leave it first
        while hall.value() == 0: await asyncio.sleep_ms(2)
        az.target = az.pos; await asyncio.sleep_ms(400); az.move_to(az.unit() + 440)
    while hall.value() == 1 and az.busy():
        await asyncio.sleep_ms(1)
    az.target = az.pos; az.v = 0
    await asyncio.sleep_ms(300)
    az.set_unit(C.AZ_HOME_DEG)
    az.vmax = C.AZ_VMAX_DEG_S * az.spu
    state["homed"] = True
    led(0, 30, 0)

# ---------------- ADS-B ----------------
def url():
    if C.ADSB_SOURCE == "local":
        return C.LOCAL_URL
    host = "api.adsb.lol" if C.ADSB_SOURCE == "adsb.lol" else "api.airplanes.live"
    return "https://%s/v2/point/%.4f/%.4f/%d" % (host, C.HOME_LAT, C.HOME_LON, C.RADIUS_NM)

def parse(js):
    out = []
    for a in js.get("ac") or js.get("aircraft") or []:
        if "lat" not in a or "lon" not in a:
            continue
        alt = a.get("alt_geom", a.get("alt_baro"))
        if alt == "ground" or alt is None or a.get("alt_baro") == "ground":
            continue
        if a.get("seen_pos", 0) > 20:
            continue
        out.append({"hex": a.get("hex", ""), "flight": (a.get("flight") or "").strip(), "r": a.get("r", ""),
                    "lat": a["lat"], "lon": a["lon"], "alt_ft": float(alt), "gs": a.get("gs", 0) or 0,
                    "track": a.get("track"), "baro_rate": a.get("baro_rate", a.get("geom_rate", 0)) or 0,
                    "age": a.get("seen_pos", 0), "t0": time.ticks_ms()})
    return out

async def adsb_task():
    global aircraft
    while True:
        try:
            r = requests.get(url(), headers={"User-Agent": "WolfTronix-PlanePointer/1.0"})
            js = r.json(); r.close()
            aircraft = parse(js)
            state["n"], state["err"], state["last_fetch"] = len(aircraft), "", time.time()
            js = None
        except Exception as e:
            state["err"] = repr(e)
            led(40, 0, 0)
        gc.collect()
        await asyncio.sleep(C.POLL_S)

def now_pos(a):
    dt = a["age"] + time.ticks_diff(time.ticks_ms(), a["t0"]) / 1000
    if a["track"] is not None and a["gs"]:
        lat, lon = geo.extrapolate(a["lat"], a["lon"], a["gs"], a["track"], dt)
    else:
        lat, lon = a["lat"], a["lon"]
    azd, eld, rng, gr = geo.az_el_range(C.HOME_LAT, C.HOME_LON, C.HOME_ALT_M, lat, lon, a["alt_ft"] * geo.FT)
    return azd, eld, rng, gr

def pick_target():
    cands = []
    for a in aircraft:
        azd, eld, rng, gr = now_pos(a)
        if eld < C.MIN_EL_DEG or gr > C.MAX_RANGE_KM * 1000:
            continue
        m = state["mode"]
        if m == "watch" and not any(w.upper() in (a["flight"].upper(), a["r"].upper(), a["hex"].upper()) for w in C.WATCH):
            continue
        if m == "arrivals" and a["baro_rate"] > -250:
            continue
        key = a["alt_ft"] if m == "lowest" else rng
        cands.append((key, a, azd, eld, rng))
    if not cands:
        return None
    cands.sort(key=lambda c: c[0])
    best = cands[0]
    cur = state["target"]
    if cur:   # hysteresis: keep current target unless the new one is clearly better
        for c in cands:
            if c[1]["hex"] == cur["hex"]:
                if best[0] > c[0] * C.SWITCH_HYST or best is c:
                    return c
                break
    return best

def announce(a, rng_m):
    h = a["hex"]
    if time.ticks_diff(time.ticks_ms(), announced.get(h, -10**9)) < C.REANNOUNCE_S * 1000:
        return
    announced[h] = time.ticks_ms()
    dest = geo.guess_destination(a, C.HOME_LAT, C.HOME_LON)
    hw = geo.octant(a["track"]) if a["track"] is not None else None
    words = announcer.sentence(a, dest, rng_m / 1000 if C.ANNOUNCE_DISTANCE else None, hw)
    print("SAY:", " ".join(words))
    dy.combo(announcer.to_codes(words))

async def control_task():
    while not state["homed"]:
        await asyncio.sleep_ms(100)
    while True:
        if state["manual"]:
            point(*state["manual"])
        else:
            t = pick_target()
            if t:
                _, a, azd, eld, rng = t
                if not state["target"] or state["target"]["hex"] != a["hex"]:
                    announce(a, rng)
                state["target"] = a
                state["rng"] = rng
                point(azd, eld)
                led(0, 0, 40)
            else:
                state["target"] = None
                if C.IDLE_POINT and C.IDLE_POINT in geo.AIRPORTS:
                    _, la, lo, h, _k = geo.AIRPORTS[C.IDLE_POINT]
                    azd, eld, _, _ = geo.az_el_range(C.HOME_LAT, C.HOME_LON, C.HOME_ALT_M, la, lo, h)
                    point(azd, max(0.0, eld))
                else:
                    point(state["az_cmd"], 0.0)
                led(0, 20, 0)
        await asyncio.sleep_ms(200)

# ---------------- tiny web UI ----------------
PAGE = """<!doctype html><meta name=viewport content="width=device-width"><title>Plane Pointer</title>
<style>body{font:16px system-ui;background:#0d1117;color:#ddd;padding:12px}a{color:#f5a524;margin-right:10px}</style>
<h2>&#9992; Plane Pointer</h2><pre id=s></pre>
<p>Mode: <a href=/mode?m=nearest>nearest</a><a href=/mode?m=lowest>lowest</a><a href=/mode?m=arrivals>arrivals</a><a href=/mode?m=watch>watch</a>
<p><a href=/home>re-home</a><a href=/vol?v=15>vol 15</a><a href=/vol?v=25>vol 25</a><a href=/point?az=0&el=45>test N 45&deg;</a><a href=/auto>auto</a>
<script>setInterval(async()=>{document.getElementById('s').textContent=JSON.stringify(await (await fetch('/s')).json(),null,1)},1000)</script>"""

async def web(reader, writer):
    try:
        line = (await reader.readline()).decode()
        while (await reader.readline()) not in (b"\r\n", b""):
            pass
        path = line.split(" ")[1] if " " in line else "/"
        q = {}
        if "?" in path:
            path, qs = path.split("?", 1)
            for kv in qs.split("&"):
                if "=" in kv:
                    k, v = kv.split("=", 1); q[k] = v
        body, ctype = PAGE, "text/html"
        if path == "/s":
            t = state["target"]
            body = json.dumps({"mode": state["mode"], "aircraft": state["n"], "target": t and (t["flight"] or t["hex"]),
                               "alt_ft": t and t["alt_ft"], "range_km": t and round(state.get("rng", 0) / 1000, 1),
                               "az_cmd": round(state["az_cmd"], 1), "el_cmd": round(state["el_cmd"], 1),
                               "az": round(az.unit() % 360, 1), "el": round(el.unit(), 1), "err": state["err"]})
            ctype = "application/json"
        elif path == "/mode":
            state["mode"] = q.get("m", "nearest"); state["manual"] = None
        elif path == "/vol":
            dy.volume(int(q.get("v", 20)))
        elif path == "/home":
            state["homed"] = False; asyncio.create_task(home())
        elif path == "/point":
            state["manual"] = (float(q.get("az", 0)), float(q.get("el", 30)))
        elif path == "/auto":
            state["manual"] = None
        if path not in ("/", "/s"):
            body = PAGE
        writer.write("HTTP/1.0 200 OK\r\nContent-Type: %s\r\n\r\n" % ctype)
        writer.write(body)
        await writer.drain()
    except Exception as e:
        print("web", e)
    writer.close()
    await writer.wait_closed()

# ---------------- boot ----------------
def wifi():
    w = network.WLAN(network.STA_IF); w.active(True)
    if not w.isconnected():
        w.connect(C.WIFI_SSID, C.WIFI_PASS)
        for _ in range(100):
            if w.isconnected(): break
            time.sleep_ms(200)
    print("IP", w.ifconfig()[0] if w.isconnected() else "-- no wifi --")
    return w.isconnected()

async def main():
    led(20, 0, 30)
    ok = wifi()
    dy.volume(C.VOLUME)
    asyncio.create_task(motion_task())
    await home()
    dy.combo(announcer.to_codes(["chime", "pointer ready"]))
    if ok:
        asyncio.create_task(adsb_task())
    asyncio.create_task(control_task())
    await asyncio.start_server(web, "0.0.0.0", 80)
    while True:
        await asyncio.sleep(60)

asyncio.run(main())
