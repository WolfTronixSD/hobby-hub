# Minimal TMC2209 single-wire UART driver. Both drivers share one bus; address set by MS1/MS2.
# Wiring: ESP TX --1k-- PDN_UART (both drivers) -- ESP RX
import time

GCONF, GSTAT, IFCNT, IHOLD_IRUN, TPOWERDOWN = 0x00, 0x01, 0x02, 0x10, 0x11
TSTEP, TPWMTHRS, TCOOLTHRS, SGTHRS, SG_RESULT, CHOPCONF, DRV_STATUS = 0x12, 0x13, 0x14, 0x40, 0x41, 0x6C, 0x6F
MRES = {256: 0, 128: 1, 64: 2, 32: 3, 16: 4, 8: 5, 4: 6, 2: 7, 1: 8}

def crc8(data):
    crc = 0
    for b in data:
        for _ in range(8):
            if ((crc >> 7) ^ (b & 1)) & 1:
                crc = ((crc << 1) ^ 0x07) & 0xFF
            else:
                crc = (crc << 1) & 0xFF
            b >>= 1
    return crc

class TMC2209:
    def __init__(self, uart, addr):
        self.u, self.a = uart, addr

    def write(self, reg, val):
        f = bytearray([0x05, self.a, reg | 0x80, (val >> 24) & 0xFF, (val >> 16) & 0xFF, (val >> 8) & 0xFF, val & 0xFF])
        f.append(crc8(f))
        self.u.read()            # flush
        self.u.write(f)
        time.sleep_ms(2)
        self.u.read()            # discard echo (single-wire bus)

    def read(self, reg):
        f = bytearray([0x05, self.a, reg & 0x7F])
        f.append(crc8(f))
        self.u.read()
        self.u.write(f)
        time.sleep_ms(6)
        r = self.u.read()
        if not r or len(r) < 12:
            return None
        r = r[-8:]               # last 8 bytes = reply (first 4 are our echo)
        if crc8(r[:7]) != r[7]:
            return None
        return (r[3] << 24) | (r[4] << 16) | (r[5] << 8) | r[6]

    def setup(self, microsteps=8, irun=18, ihold=8, sgthrs=0):
        self.write(GCONF, 0x1C1)                 # I_scale_analog, pdn_disable, mstep_reg_select, multistep_filt; stealthChop
        self.write(CHOPCONF, (0x10000053 & ~(0xF << 24)) | (MRES[microsteps] << 24))   # intpol on
        self.write(IHOLD_IRUN, (6 << 16) | (irun << 8) | ihold)
        self.write(TPOWERDOWN, 20)
        self.write(TPWMTHRS, 0)                  # always stealthChop
        self.write(TCOOLTHRS, 0xFFFFF)           # StallGuard -> DIAG active at all speeds
        self.write(SGTHRS, sgthrs)

    def current(self, irun, ihold):
        self.write(IHOLD_IRUN, (6 << 16) | (irun << 8) | ihold)

    def sg(self):
        return self.read(SG_RESULT)

    def alive(self):
        return self.read(IFCNT) is not None
