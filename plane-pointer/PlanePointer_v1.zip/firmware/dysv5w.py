# DY-SV5W UART driver (9600 8N1). Set the DIP switches to UART mode (as in your chest-plate build).
# Frame: AA <cmd> <len> <data...> <sum of all previous bytes & 0xFF>
from machine import UART, Pin

class DY:
    def __init__(self, uart_id, tx, rx, busy_pin=None):
        self.u = UART(uart_id, 9600, tx=tx, rx=rx)
        self.busy = Pin(busy_pin, Pin.IN, Pin.PULL_UP) if busy_pin is not None else None

    def _send(self, cmd, data=b""):
        f = bytearray([0xAA, cmd, len(data)]) + bytes(data)
        f.append(sum(f) & 0xFF)
        self.u.write(f)

    def volume(self, v):          self._send(0x13, bytes([max(0, min(30, v))]))
    def play(self):               self._send(0x02)
    def stop(self):               self._send(0x04)
    def play_track(self, n):      self._send(0x07, bytes([n >> 8, n & 0xFF]))

    def combo(self, names):
        """Play /ZH/<name>.mp3 files back to back. names = ['0A','12',...] (2-char each)."""
        if not names:
            return
        data = "".join(names).encode()
        self._send(0x1B, data)

    def end_combo(self):          self._send(0x1C)

    def playing(self):
        return self.busy is not None and self.busy.value() == 0   # BUSY is low while playing
