# Geodesy: WGS-84 ECEF -> local ENU, so azimuth/elevation include earth curvature.
# bearing() is the same great-circle initial bearing used in the NAV -> KMYF app.
import math

A = 6378137.0
E2 = 6.69437999014e-3
FT = 0.3048
NM = 1852.0

AIRPORTS = {  # ICAO: (name spoken, lat, lon, elev m, kind)  kind: air = airline, ga, mil
    "KMYF": ("Montgomery", 32.8157, -117.1396, 129, "ga"),
    "KSAN": ("Lindbergh", 32.7336, -117.1897, 5, "air"),
    "KCRQ": ("Palomar", 33.1283, -117.2800, 101, "ga"),
    "KNKX": ("Miramar", 32.8684, -117.1425, 146, "mil"),
    "KSEE": ("Gillespie", 32.8262, -116.9724, 117, "ga"),
    "KRNM": ("Ramona", 33.0392, -116.9154, 421, "ga"),
    "KNZY": ("North Island", 32.6992, -117.2153, 8, "mil"),
    "KSDM": ("Brown Field", 32.5723, -116.9802, 160, "ga"),
    "KOKB": ("Oceanside", 33.2190, -117.3494, 8, "ga"),
    "KLAX": ("Los Angeles", 33.9425, -118.4081, 38, "air"),
    "KONT": ("Ontario", 34.0560, -117.6012, 287, "air"),
    "KSNA": ("John Wayne", 33.6757, -117.8682, 17, "air"),
    "KPSP": ("Palm Springs", 33.8297, -116.5067, 145, "air"),
}

def ecef(lat, lon, h):
    la, lo = math.radians(lat), math.radians(lon)
    n = A / math.sqrt(1 - E2 * math.sin(la) ** 2)
    return ((n + h) * math.cos(la) * math.cos(lo),
            (n + h) * math.cos(la) * math.sin(lo),
            (n * (1 - E2) + h) * math.sin(la))

def enu(lat0, lon0, h0, lat, lon, h):
    x0, y0, z0 = ecef(lat0, lon0, h0)
    x, y, z = ecef(lat, lon, h)
    dx, dy, dz = x - x0, y - y0, z - z0
    la, lo = math.radians(lat0), math.radians(lon0)
    e = -math.sin(lo) * dx + math.cos(lo) * dy
    n = -math.sin(la) * math.cos(lo) * dx - math.sin(la) * math.sin(lo) * dy + math.cos(la) * dz
    u = math.cos(la) * math.cos(lo) * dx + math.cos(la) * math.sin(lo) * dy + math.sin(la) * dz
    return e, n, u

def az_el_range(lat0, lon0, h0, lat, lon, h):
    """returns (azimuth deg true, elevation deg, slant range m, ground range m)"""
    e, n, u = enu(lat0, lon0, h0, lat, lon, h)
    g = math.sqrt(e * e + n * n)
    az = math.degrees(math.atan2(e, n)) % 360
    el = math.degrees(math.atan2(u, g))
    return az, el, math.sqrt(g * g + u * u), g

def bearing(lat1, lon1, lat2, lon2):
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dl = math.radians(lon2 - lon1)
    y = math.sin(dl) * math.cos(p2)
    x = math.cos(p1) * math.sin(p2) - math.sin(p1) * math.cos(p2) * math.cos(dl)
    return math.degrees(math.atan2(y, x)) % 360

def haversine_km(lat1, lon1, lat2, lon2):
    p1, p2 = math.radians(lat1), math.radians(lat2)
    a = math.sin((p2 - p1) / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(math.radians(lon2 - lon1) / 2) ** 2
    return 6371.0 * 2 * math.asin(math.sqrt(a))

def extrapolate(lat, lon, gs_kt, track_deg, dt_s):
    """dead-reckon a position forward dt seconds"""
    d = gs_kt * NM / 3600 * dt_s
    t = math.radians(track_deg)
    return (lat + d * math.cos(t) / 111320.0,
            lon + d * math.sin(t) / (111320.0 * math.cos(math.radians(lat))))

def ang_diff(a, b):
    return (a - b + 540) % 360 - 180

def guess_destination(ac, home_lat, home_lon):
    """No route API needed: descending aircraft whose track points at a nearby airport -> 'inbound X'.
       Climbing aircraft close to an airport -> 'departing X'.  Returns (verb, name) or None."""
    lat, lon = ac["lat"], ac["lon"]
    alt = ac.get("alt_ft", 0) or 0
    vs = ac.get("baro_rate", 0) or 0
    trk = ac.get("track")
    if trk is None:
        return None
    cs = (ac.get("flight") or "").upper()
    if cs[:1] == "N" and cs[1:2].isdigit():
        kinds = ("ga",)                       # private N-number
    elif len(cs) > 3 and cs[:3].isalpha() and cs[3].isdigit():
        kinds = ("air",)                      # airline / cargo ICAO callsign
    else:
        kinds = ("air", "ga", "mil")          # unknown (military, unusual) -> anything
    best = None
    for icao, (name, alat, alon, _, kind) in AIRPORTS.items():
        if kind not in kinds:
            continue
        d = haversine_km(lat, lon, alat, alon)
        if vs < -250 and alt < 14000 and d < 90:
            off = abs(ang_diff(bearing(lat, lon, alat, alon), trk))
            score = off + d * 0.15
            if off < 30 and (best is None or score < best[0]):
                best = (score, "inbound", name)
        elif vs > 300 and d < 12 and alt < 8000:
            score = d
            if best is None or score < best[0]:
                best = (score, "departing", name)
    return (best[1], best[2]) if best else None

OCTANTS = ["north", "northeast", "east", "southeast", "south", "southwest", "west", "northwest"]
def octant(track):
    return OCTANTS[int(((track % 360) + 22.5) // 45) % 8]
