# Builds spoken sentences out of short MP3 clips stored on the DY-SV5W SD card in /ZH/xx.mp3
# and plays them back-to-back with the module's "combination play" UART command (AA 1B ...).
#   "Southwest one two three four, eight thousand five hundred feet, inbound Lindbergh"
# make_clips.py (run on your PC) generates every clip in CLIPS with a TTS voice.

AIRLINES = {
    "SWA": "Southwest", "ASA": "Alaska", "UAL": "United", "AAL": "American", "DAL": "Delta",
    "SKW": "SkyWest", "JBU": "JetBlue", "FFT": "Frontier", "NKS": "Spirit", "HAL": "Hawaiian",
    "FDX": "FedEx", "UPS": "U P S", "AAY": "Allegiant", "QXE": "Horizon", "ENY": "Envoy",
    "RPA": "Brickyard", "WJA": "WestJet", "ACA": "Air Canada", "VOI": "Volaris", "AMX": "Aeromexico",
    "BAW": "Speedbird", "JAL": "Japan Air", "KAL": "Korean Air", "CPA": "Cathay", "AFR": "Air France",
    "DLH": "Lufthansa", "EDV": "Endeavor", "GTI": "Giant", "ABX": "Abex", "CNS": "Cobalt",
}
PHONETIC = ["alpha", "bravo", "charlie", "delta", "echo", "foxtrot", "golf", "hotel", "india", "juliett",
            "kilo", "lima", "mike", "november", "oscar", "papa", "quebec", "romeo", "sierra", "tango",
            "uniform", "victor", "whiskey", "x-ray", "yankee", "zulu"]
DIGITS = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "niner"]
TEENS = ["ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"]
TENS = {20: "twenty", 30: "thirty", 40: "forty", 50: "fifty"}
WORDS = ["thousand", "hundred", "feet", "inbound", "departing", "heading", "miles", "out", "flight level",
         "north", "northeast", "east", "southeast", "south", "southwest", "west", "northwest",
         "traffic", "low", "helicopter", "pointer ready", "no traffic", "pointing at", "chime"]
AIRPORT_NAMES = ["Montgomery", "Lindbergh", "Palomar", "Miramar", "Gillespie", "Ramona", "North Island",
                 "Brown Field", "Oceanside", "Los Angeles", "Ontario", "John Wayne", "Palm Springs"]

def _all_words():
    seen, out = set(), []
    for w in (["chime"] + list(AIRLINES.values()) + PHONETIC + DIGITS + TEENS + list(TENS.values()) + WORDS + AIRPORT_NAMES):
        if w not in seen:
            seen.add(w); out.append(w)
    return out

_CH = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
def _code(i):
    return _CH[i // 36] + _CH[i % 36]

CLIPS = {w: _code(i + 1) for i, w in enumerate(_all_words())}   # word -> 2-char file name in /ZH

def number_words(n):
    """0..59 -> words list"""
    if n < 10: return [DIGITS[n] if n != 9 else "niner"]
    if n < 20: return [TEENS[n - 10]]
    t, u = (n // 10) * 10, n % 10
    return [TENS[t]] + ([DIGITS[u]] if u else [])

def callsign_words(cs):
    cs = (cs or "").strip().upper()
    if not cs: return []
    if cs[0] == "N" and len(cs) > 1 and cs[1].isdigit():           # N-number
        out = ["november"]
        for ch in cs[1:]:
            out.append(DIGITS[int(ch)] if ch.isdigit() else PHONETIC[ord(ch) - 65])
        return out
    pre = cs[:3]
    if pre in AIRLINES and len(cs) > 3:
        out, rest = [AIRLINES[pre]], cs[3:]
    else:
        out, rest = [], cs                     # unknown operator: spell it out
    for ch in rest:
        if ch.isdigit(): out.append(DIGITS[int(ch)])
        elif "A" <= ch <= "Z": out.append(PHONETIC[ord(ch) - 65])
    return out

def altitude_words(ft):
    ft = int(round(ft / 100.0)) * 100
    if ft >= 18000:
        fl = ft // 100
        return ["flight level"] + [DIGITS[int(c)] for c in str(fl)]
    th, hu = ft // 1000, (ft % 1000) // 100
    out = []
    if th: out += number_words(th) + ["thousand"]
    if hu: out += [DIGITS[hu] if hu != 9 else "niner", "hundred"]
    if not out: out = ["zero"]
    return out + ([] if ft >= 18000 else ["feet"])

def sentence(ac, dest=None, dist_km=None, heading_word=None):
    w = ["chime"] + callsign_words(ac.get("flight") or ac.get("r") or "")
    w += altitude_words(ac.get("alt_ft", 0))
    if dest:
        w += [dest[0], dest[1]]
    elif heading_word:
        w += ["heading", heading_word]
    if dist_km is not None:
        mi = int(round(dist_km * 0.621371))
        if 0 < mi < 60:
            w += number_words(mi) + ["miles"]
    return w

def to_codes(words):
    return [CLIPS[w] for w in words if w in CLIPS]
